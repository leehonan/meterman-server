'''

================================================================================================================================================================
meter_db.py
=====================
TODO: rename


================================================================================================================================================================

'''

import sqlite3
from enum import Enum

from meterman import app_base as base


# Database Record Statuses
class RecStatus(Enum):
    NORMAL = 0
    HIDDEN = 1
    DELETED = 2


# noinspection SqlDialectInspection
class DBManager:
    """
    TBD...

    """


    def do_vacuum(self):
        self.connection.isolation_level = None
        self.connection.execute("VACUUM")  # TODO: confirm won't pause startup for too long
        self.connection.isolation_level = ""


    def __init__(self, database_file_uri):

        try:
            self.logger = base.get_logger('db_mgr')
            self.db_uri = database_file_uri
            self.connection = sqlite3.connect(database_file_uri, check_same_thread=False)       # TODO: ensure access thread-safe
            self.connection.row_factory = sqlite3.Row

            cursor = self.connection.cursor()

            cursor.execute('SELECT sqlite_version()')
            self.db_version = cursor.fetchone()
            self.logger.info('Connected to sqlite DB.  Version is: {0}'.format(self.db_version))

            cursor.execute('CREATE TABLE IF NOT EXISTS meter_entry ('
                            'node_uuid data_type TEXT NOT NULL, '
                            'timestamp_raw data_type INTEGER NOT NULL, '
                            'timestamp_raw_nonce data_type TEXT NOT NULL, '
                            'timestamp data_type INTEGER NOT NULL, '
                            'entry_type data_type TEXT NOT NULL, '
                            'entry_value data_type INTEGER NOT NULL, '
                            'entry_interval data_type INTEGER NOT NULL, '
                            'meter_value data_type INTEGER NOT NULL, '
                            'rec_status data_type INTEGER NOT NULL,'
                            'PRIMARY KEY (node_uuid, timestamp_raw, timestamp_raw_nonce)) WITHOUT ROWID')

            cursor.execute('CREATE INDEX IF NOT EXISTS idx_meter_entry_node_uuid ON meter_entry (node_uuid)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_meter_entry_timestamp ON meter_entry (timestamp)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_meter_entry_entry_type ON meter_entry (entry_type)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_meter_entry_rec_status ON meter_entry (rec_status)')

            cursor.execute('CREATE TABLE IF NOT EXISTS gateway_snapshot ('
                           'gateway_uuid data_type TEXT NOT NULL, '
                           'when_snapshot data_type INTEGER NOT NULL, '
                           'network_id data_type TEXT NOT NULL, '
                           'gateway_id data_type INTEGER NOT NULL, '
                           'when_booted data_type INTEGER NOT NULL, '
                           'free_ram data_type INTEGER NOT NULL, '
                           'approx_clock_drift data_type INTEGER NOT NULL, '
                           'log_level data_type TEXT NOT NULL, '
                           'tx_power data_type INTEGER NOT NULL,'
                           'meter_unit data_type TEXT NOT NULL,'
                            'rec_status data_type INTEGER NOT NULL,'
                           'PRIMARY KEY (gateway_uuid, when_snapshot)) WITHOUT ROWID')

            cursor.execute('CREATE INDEX IF NOT EXISTS idx_gateway_snapshot_uuid ON gateway_snapshot (gateway_uuid)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_gateway_snapshot_rec_status ON gateway_snapshot (rec_status)')

            cursor.execute('CREATE TABLE IF NOT EXISTS node_snapshot ('
                           'node_uuid data_type TEXT NOT NULL, '
                           'when_snapshot data_type INTEGER NOT NULL, '
                           'network_id data_type TEXT NOT NULL, '
                           'node_id data_type INTEGER NOT NULL, '
                           'gateway_id data_type INTEGER NOT NULL, '
                           'batt_voltage_mv data_type INTEGER NOT NULL, '
                           'up_time data_type INTEGER NOT NULL, '
                           'sleep_time data_type INTEGER NOT NULL, '
                           'free_ram data_type INTEGER NOT NULL, '
                           'last_seen data_type INTEGER NOT NULL, '
                           'last_clock_drift data_type INTEGER NOT NULL, '
                           'meter_interval data_type INTEGER NOT NULL, '
                           'last_meter_entry data_type INTEGER NOT NULL, '
                           'last_meter_value data_type INTEGER NOT NULL, '
                           'puck_led_rate data_type INTEGER NOT NULL, '
                           'puck_led_time data_type INTEGER NOT NULL, '
                           'last_rssi_at_gateway data_type INTEGER NOT NULL, '
                            'rec_status data_type INTEGER NOT NULL,'
                           'PRIMARY KEY (node_uuid, when_snapshot)) WITHOUT ROWID')

            cursor.execute('CREATE INDEX IF NOT EXISTS idx_node_snapshot_uuid ON node_snapshot (node_uuid)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_node_snapshot_network_id ON node_snapshot (network_id)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_node_snapshot_rec_status ON node_snapshot (rec_status)')

            cursor.execute('CREATE TABLE IF NOT EXISTS node_event ('
                            'event_id data_type INTEGER PRIMARY KEY, '
                            'node_uuid data_type TEXT NOT NULL, '
                            'timestamp data_type INT NOT NULL, '
                            'event_type  data_type TEXT NOT NULL, '
                            'details data_type TEXT NOT NULL)')

            cursor.execute('CREATE INDEX IF NOT EXISTS idx_node_event_node_uuid ON node_event (node_uuid)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_node_event_timestamp ON node_event (timestamp)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_node_event_event_type ON node_event (event_type)')

            cursor.execute('CREATE TABLE IF NOT EXISTS sys_param ('
                           'name data_type TEXT NOT NULL, '
                           'value data_type TEXT NOT NULL, '
                           'PRIMARY KEY (name)) WITHOUT ROWID')

            cursor.execute('CREATE INDEX IF NOT EXISTS idx_sys_param_name ON sys_param (name)')

            cursor.execute('CREATE TABLE IF NOT EXISTS user ('
                           'username data_type TEXT NOT NULL, '
                           'password data_type TEXT NOT NULL, '
                           'permissions data_type TEXT NOT NULL, '            
                           'PRIMARY KEY (username)) WITHOUT ROWID')

            cursor.execute('CREATE INDEX IF NOT EXISTS idx_user_username ON user (username)')

            self.connection.commit()
            cursor.close()

            self.do_vacuum()

        except sqlite3.Error as err:
            self.logger.info('sqlite3 Error: {0}'.format(err))


    def conn_open(self):
        self.connection = sqlite3.connect(self.db_uri)
        self.connection.row_factory = sqlite3.Row

    def conn_close(self):
        self.connection.commit()  # redundant, just in case
        self.connection.close()


    def __exit__(self, exc_type, exc_value, traceback):
        self.conn_close()   # redundant, just in case


    def write_meter_entry(self, node_uuid, timestamp_raw, timestamp_raw_nonce, timestamp, entry_type, entry_value, entry_interval, meter_value, rec_status):
        try:
            cursor = self.connection.cursor()
            cmd = 'INSERT INTO meter_entry (node_uuid, timestamp_raw, timestamp_raw_nonce, timestamp, entry_type, entry_value, entry_interval, meter_value, rec_status)' \
                  ' VALUES ("{0}", {1}, "{2}", {3}, {4}, {5}, {6}, {7}, {8})' \
                .format(node_uuid, timestamp_raw, timestamp_raw_nonce, timestamp, entry_type, entry_value, entry_interval, meter_value, rec_status)
            cursor.execute(cmd)
            self.logger.debug('Inserted meter_entry record for PRIMARY KEY [{0},{1},{2}]'.format(node_uuid, timestamp_raw, timestamp_raw_nonce))
            self.connection.commit()
            cursor.close()

        except sqlite3.IntegrityError:
            self.logger.warn('ERROR: ID already exists in PRIMARY KEY [{0},{1},{2}]'.format(node_uuid, timestamp_raw, timestamp_raw_nonce))

        except sqlite3.Error as err:
            self.logger.warn('sqlite3 Error: {0}'.format(err))


    def update_meter_entry(self, node_uuid, timestamp_raw, timestamp_raw_nonce, timestamp, entry_type, entry_value, entry_interval, meter_value, rec_status):
        try:

            if node_uuid is None or timestamp_raw is None or timestamp_raw_nonce is None:
                raise ValueError('Primary key not given.  Got of node_uuid={0), timestamp_raw={1}, timestamp_raw_nonce={2}.'.format(node_uuid, timestamp_raw, timestamp_raw_nonce))

            if timestamp is None or entry_type is None or meter_value is None or rec_status is None:
                raise ValueError('No update columns given.')


            # Build SQL update command...
            cmd = 'UPDATE meter_entry SET '

            if timestamp is not None:
                cmd += 'timestamp = {},'.format(timestamp)
            if entry_type is not None:
                cmd += 'entry_type = {},'.format(entry_type)
            if entry_value is not None:
                cmd += 'entry_value = {},'.format(entry_value)
            if entry_interval is not None:
                cmd += 'entry_interval = {},'.format(entry_interval)
            if meter_value is not None:
                cmd += 'meter_value = {},'.format(meter_value)
            if rec_status is not None:
                cmd += 'rec_status = {},'.format(rec_status)

            cmd = cmd[:-1] + ' '      # replace trailing comma with space

            cmd += 'WHERE node_uuid = "{0}", timestamp_raw = {1}, timestamp_raw_nonce = {2}'.format(
                node_uuid, timestamp_raw, timestamp_raw_nonce
                )

            cursor = self.connection.cursor()
            cursor.execute(cmd)
            self.logger.debug('Updated meter_entry record for PRIMARY KEY [{0},{1},{2}]'.format(node_uuid, timestamp_raw, timestamp_raw_nonce))
            self.connection.commit()
            cursor.close()

        except ValueError as err:
            self.logger.warn('Value Error: {0}'.format(err))

        except sqlite3.IntegrityError as err:
            self.logger.warn('sqlite3 IntegrityError: {0}'.format(err))

        except sqlite3.Error as err:
            self.logger.warn('sqlite3 Error: {0}'.format(err))


    def get_node_meter_entries_count(self, node_uuid=None, entry_type=None, rec_status=None):
        cmd = 'SELECT COUNT(*) FROM meter_entry'

        if any(node_uuid or entry_type or rec_status) is not None:
            cmd += ' WHERE '
        if node_uuid is not None:
            cmd += 'node_uuid = "{}" AND '.format(node_uuid)
        if entry_type is not None:
            cmd += 'entry_type = {} AND '.format(entry_type)
        if rec_status is not None:
            cmd += 'rec_status = {} AND '.format(rec_status)

        if cmd.endswith('AND '):
            cmd = cmd[:-4] + ' '  # replace trailing "AND " with space
        cursor = self.connection.cursor()
        cursor.execute(cmd)
        count = cursor.fetchall()
        cursor.close()
        return count[0][0]


    def get_node_meter_entries(self, node_uuid=None, entry_type=None, rec_status=None, time_from=None, time_to=None,
                               just_latest=False, limit_count=1000):
        """
        Simple query function.  Use direct SQL otherwise.

        """

        try:
            if time_from is not None and just_latest is not None:
                raise ValueError('Mutually exclusive criteria: time_from and just_latest')
            # Build SQL update command...
            cmd = 'SELECT * FROM meter_entry'

            if any(node_uuid or entry_type or rec_status) is not None:
                cmd += ' WHERE '
            if node_uuid is not None:
                cmd += 'node_uuid = "{}" AND '.format(node_uuid)
            if entry_type is not None:
                cmd += 'entry_type = {} AND '.format(entry_type)
            if rec_status is not None:
                cmd += 'rec_status = {} AND '.format(rec_status)
            if time_from is not None:
                cmd += 'timestamp >= {} AND '.format(time_from)
            if time_to is not None:
                cmd += 'timestamp <= {} AND '.format(time_to)

            if cmd.endswith('AND '):
                cmd = cmd[:-4] + ' '  # replace trailing "AND " with space

            if limit_count is not None:
                cmd += 'ORDER BY timestamp ASC LIMIT {0}'.format(limit_count)

            cursor = self.connection.cursor()
            cursor.execute(cmd)
            rows = cursor.fetchall()
            cursor.close()
            return rows

        except sqlite3.Error as err:
            self.logger.warn('sqlite3 Error: {0}'.format(err))


    def delete_node_meter_entry(self, node_uuid, timestamp_raw, timestamp_raw_nonce):
        try:
            cursor = self.connection.cursor()
            cursor.execute('DELETE FROM meter_entry WHERE node_uuid = "{0}" AND timestamp_raw = {1} AND timestamp_raw_nonce = "{2}"'.format(
                node_uuid, timestamp_raw, timestamp_raw_nonce
            ))
            cursor.close()

        except sqlite3.Error as err:
            self.logger.warn('sqlite3 Error: {0}'.format(err))


    def write_gateway_snapshot(self, gateway_uuid, when_snapshot, network_id, gateway_id, when_booted, free_ram,
                               approx_clock_drift, log_level, tx_power, meter_unit, rec_status):
        try:
            cursor = self.connection.cursor()
            cmd = 'INSERT INTO gateway_snapshot (gateway_uuid, when_snapshot, network_id, gateway_id, when_booted, free_ram, \
                        approx_clock_drift, log_level, tx_power, meter_unit, rec_status)' \
                  ' VALUES ("{0}", {1}, "{2}", {3}, {4}, {5}, {6}, "{7}", {8}, "{9}", {10})' \
                .format(gateway_uuid, when_snapshot, network_id, gateway_id, when_booted, free_ram,
                                approx_clock_drift, log_level, tx_power, meter_unit, rec_status)
            cursor.execute(cmd)
            self.logger.debug('Inserted gateway_snapshot record for PRIMARY KEY [{0},{1}]'.format(gateway_uuid, when_snapshot))
            self.connection.commit()
            cursor.close()

        except sqlite3.IntegrityError:
            self.logger.warn('ERROR: ID already exists in PRIMARY KEY [{0},{1}]'.format(gateway_uuid, when_snapshot))

        except sqlite3.Error as err:
            self.logger.warn('sqlite3 Error: {0}'.format(err))


    def get_gateway_snapshot(self, gateway_uuid=None, rec_status=None, just_latest=False, limit_count=1):
        """
        Simple query function.  Use direct SQL otherwise.

        """

        try:
            # Build SQL update command...
            cmd = 'SELECT * FROM gateway_snapshot'

            if any(gateway_uuid or rec_status) is not None:
                cmd += ' WHERE '
            if gateway_uuid is not None:
                cmd += 'node_uuid = "{}" AND '.format(gateway_uuid)
            if rec_status is not None:
                cmd += 'rec_status = {} AND '.format(rec_status)

            if cmd.endswith('AND '):
                cmd = cmd[:-4] + ' '  # replace trailing "AND " with space

            if limit_count is not None:
                cmd += ' ORDER BY timestamp ASC LIMIT {0}'.format(limit_count)

            cursor = self.connection.cursor()
            cursor.execute(cmd)
            rows = cursor.fetchall()
            cursor.close()
            return rows

        except sqlite3.Error as err:
            self.logger.warn('sqlite3 Error: {0}'.format(err))


    def write_node_snapshot(self, node_uuid, when_snapshot, network_id, node_id, gateway_id, batt_voltage_mv, up_time, sleep_time, free_ram, last_seen, last_clock_drift,
                            meter_interval, last_meter_entry, last_meter_value, puck_led_rate, puck_led_time, last_rssi_at_gateway, rec_status):
        try:
            cursor = self.connection.cursor()
            cmd = 'INSERT INTO node_snapshot (node_uuid, when_snapshot, network_id, node_id, gateway_id, batt_voltage_mv, up_time, sleep_time, free_ram, last_seen, ' \
                                                'last_clock_drift, meter_interval, last_meter_entry, last_meter_value, puck_led_rate,  puck_led_time, ' \
                                                'last_rssi_at_gateway, rec_status) ' \
                                                'VALUES ("{0}", {1}, "{2}", {3}, {4}, {5}, {6}, {7}, {8}, {9}, {10}, {11}, {12}, {13}, {14}, {15}, {16}, {17})'.format(
                                                        node_uuid, when_snapshot, network_id, node_id, gateway_id, batt_voltage_mv, up_time, sleep_time, free_ram,
                                                        last_seen, last_clock_drift, meter_interval, last_meter_entry, last_meter_value, puck_led_rate,
                                                        puck_led_time, last_rssi_at_gateway, rec_status)
            cursor.execute(cmd)
            self.logger.debug('Inserted node_snapshot record for PRIMARY KEY [{0},{1}]'.format(node_uuid, when_snapshot))
            self.connection.commit()
            cursor.close()

        except sqlite3.IntegrityError:
            self.logger.warn('ERROR: ID already exists in PRIMARY KEY [{0},{1}]'.format(node_uuid, when_snapshot))

        except sqlite3.Error as err:
            self.logger.warn('sqlite3 Error: {0}'.format(err))


    def get_node_snapshot(self, node_uuid=None, network_id=None, rec_status=None, just_latest=False, limit_count=1):
        """
        Simple query function.  Use direct SQL otherwise.

        """

        try:
            # Build SQL update command...
            cmd = 'SELECT * FROM node_snapshot'

            if any(node_uuid or network_id or rec_status) is not None:
                cmd += ' WHERE '
            if node_uuid is not None:
                cmd += 'node_uuid = "{}" AND '.format(node_uuid)
            if network_id is not None:
                cmd += 'network_id = {} AND '.format(network_id)
            if rec_status is not None:
                cmd += 'rec_status = {} AND '.format(rec_status)

            if cmd.endswith('AND '):
                cmd = cmd[:-4] + ' '  # replace trailing "AND " with space

            if limit_count is not None:
                cmd += ' ORDER BY timestamp ASC LIMIT {0}'.format(limit_count)

            cursor = self.connection.cursor()
            cursor.execute(cmd)
            rows = cursor.fetchall()
            cursor.close()
            return rows

        except sqlite3.Error as err:
            self.logger.warn('sqlite3 Error: {0}'.format(err))


    def write_node_event(self, node_uuid, timestamp, event_type, details):
        try:
            cursor = self.connection.cursor()
            cmd = 'INSERT INTO node_event (node_uuid, timestamp, event_type, details)' \
                  ' VALUES ("{0}", {1}, "{2}", "{3}")' \
                .format(node_uuid, timestamp, event_type, details)
            cursor.execute(cmd)
            self.logger.debug('Inserted node_event record with node={0}, event type={1}'.format(node_uuid, event_type))
            self.connection.commit()
            cursor.close()

        except sqlite3.IntegrityError:
            self.logger.warn('ERROR: ID already exists in PRIMARY KEY ')

        except sqlite3.Error as err:
            self.logger.warn('sqlite3 Error: {0}'.format(err))


    def get_node_event(self, node_uuid=None, time_from=None, time_to=None, event_type=None):
        """
        Simple query function.  Use direct SQL otherwise.

        """

        try:
            # Build SQL update command...
            cmd = 'SELECT * FROM node_event'

            if any(node_uuid or time_from or time_to or event_type) is not None:
                cmd += ' WHERE '
            if node_uuid is not None:
                cmd += 'node_uuid = "{}" AND '.format(node_uuid)
            if time_from is not None:
                cmd += 'timestamp >= {} AND '.format(time_from)
            if time_to is not None:
                cmd += 'timestamp <= {} AND '.format(time_to)
            if event_type is not None:
                cmd += 'event_type = {} AND '.format(event_type)

            if cmd.endswith('AND '):
                cmd = cmd[:-4] + ' '  # replace trailing "AND " with space

            cursor = self.connection.cursor()
            cursor.execute(cmd)
            rows = cursor.fetchall()
            cursor.close()
            return rows

        except sqlite3.Error as err:
            self.logger.warn('sqlite3 Error: {0}'.format(err))


    def write_sys_param(self, name, value):
        try:
            cursor = self.connection.cursor()
            cmd = 'INSERT INTO sys_param (name, value)' \
                  ' VALUES ("{0}", {1})' \
                .format(name, value)
            cursor.execute(cmd)
            self.logger.debug('Inserted sys_param record with name={0}, value={1}'.format(name, value))
            self.connection.commit()
            cursor.close()

        except sqlite3.IntegrityError:
            self.logger.warn('ERROR: ID already exists in PRIMARY KEY [{0}]'.format(name))

        except sqlite3.Error as err:
            self.logger.warn('sqlite3 Error: {0}'.format(err))


    def get_sys_param(self, name):
        """
        Simple query function.  Use direct SQL otherwise.

        """

        try:
            # Build SQL update command...
            cmd = 'SELECT * FROM sys_param WHERE name = "{}"'.format(name)
            cursor = self.connection.cursor()
            cursor.execute(cmd)
            rows = cursor.fetchall()
            cursor.close()
            return rows

        except sqlite3.Error as err:
            self.logger.warn('sqlite3 Error: {0}'.format(err))


    def update_sys_param(self, name, value):
        try:

            if name is None or value is None:
                raise ValueError('Invalid sys_param update.  Got of name={0), value={1}.'.format(name, value))

            # Build SQL update command...
            cmd = 'UPDATE sys_param SET value = {0} WHERE name = "{1}"'.format(value, name)

            cursor = self.connection.cursor()
            cursor.execute(cmd)
            self.logger.debug('Updated sys_param record for PRIMARY KEY [{0}]'.format(name))
            self.connection.commit()
            cursor.close()

        except ValueError as err:
            self.logger.warn('Value Error: {0}'.format(err))

        except sqlite3.IntegrityError as err:
            self.logger.warn('sqlite3 IntegrityError: {0}'.format(err))

        except sqlite3.Error as err:
            self.logger.warn('sqlite3 Error: {0}'.format(err))


    def write_user(self, username, password, permissions):
        try:
            cursor = self.connection.cursor()
            cmd = 'INSERT INTO user (username, password, permissions)' \
                  ' VALUES ("{0}", {1}, {2})' \
                .format(username, password, permissions)
            cursor.execute(cmd)
            self.logger.debug('Inserted user record with username={0}'.format(username))
            self.connection.commit()
            cursor.close()

        except sqlite3.IntegrityError:
            self.logger.warn('ERROR: ID already exists in PRIMARY KEY [{0}]'.format(username))

        except sqlite3.Error as err:
            self.logger.warn('sqlite3 Error: {0}'.format(err))


    def get_user(self, username):
        """
        Simple query function.  Use direct SQL otherwise.

        """

        try:
            # Build SQL update command...
            cmd = 'SELECT * FROM user WHERE username = "{}"'.format(username)
            cursor = self.connection.cursor()
            cursor.execute(cmd)
            rows = cursor.fetchall()
            cursor.close()
            return rows

        except sqlite3.Error as err:
            self.logger.warn('sqlite3 Error: {0}'.format(err))


    def update_user(self, username, password, permissions):
        try:

            if username is None or (password is None and permissions is None):
                raise ValueError('Invalid user update for username={0)'.format(username))

            # Build SQL update command...
            cmd = 'UPDATE user SET '

            if password is not None:
                cmd += 'password = {0}'.format(password) + ' AND '

            if permissions is not None:
                cmd += 'permissions = {0}'.format(permissions) + ' AND '

            if cmd.endswith('AND '):
                cmd = cmd[:-4] + ' '  # replace trailing "AND " with space

            cmd += 'WHERE username = "{0}"'.format(username)

            cursor = self.connection.cursor()
            cursor.execute(cmd)
            self.logger.debug('Updated user record for PRIMARY KEY [{0}]'.format(username))
            self.connection.commit()
            cursor.close()

        except ValueError as err:
            self.logger.warn('Value Error: {0}'.format(err))

        except sqlite3.IntegrityError as err:
            self.logger.warn('sqlite3 IntegrityError: {0}'.format(err))

        except sqlite3.Error as err:
            self.logger.warn('sqlite3 Error: {0}'.format(err))
