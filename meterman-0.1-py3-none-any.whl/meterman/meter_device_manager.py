'''

================================================================================================================================================================
meter_device_manager.py
=====================


TODO: remove assumption of one gateway only, every node as child of that
================================================================================================================================================================

'''

from meterman import app_base as base
import arrow
from meterman import gateway_messages as gmsg
from meterman import meter_device_gateway as gway

NODE_UPDATE_INTERVAL_SECS = 60

class MeterDeviceManager:

    def __init__(self, meter_man, gateway_config_oride=None):
        self.logger = base.get_logger('device_mgr')

        self.gateways = {}

        if gateway_config_oride:
            # used for testing, single gateway
            gateway_configs = [gateway_config_oride]
        else:
            gateway_configs = [x for x in base.config.sections() if x.startswith('Gateway')]

        for gateway in gateway_configs:
            if gateway_config_oride:
                gw_config = gateway
            else:
                gw_config = base.config[gateway]
            gateway_uuid = self.get_node_uuid(gw_config['network_id'], gw_config['gateway_id'])
            self.gateways[gateway_uuid] = {}
            self.gateways[gateway_uuid]['gw_obj'] = gway.MeterDeviceGateway(
                self, network_id=gw_config['network_id'], gateway_id=gw_config['gateway_id'],
                label=gw_config['label'],
                serial_port=gw_config['serial_port'], serial_baud=gw_config['serial_baud'])
            self.gateways[gateway_uuid]['last_rx_msg_obj'] = ''
            self.gateways[gateway_uuid]['last_snap_time'] = 0

        self.meters = {}

        self.meter_man = meter_man


    def get_node_uuid(self, network_id, node_id):
        return network_id + '.' + node_id


    def ensure_node_exists(self, node_uuid):
        if node_uuid not in self.meters:
            self.meters[node_uuid] = {}
            self.meter_man.register_node(node_uuid)


    def uts_to_str(self, utc_timestamp):
        return arrow.get(utc_timestamp).to('local').format('YYYY-MM-DD HH:mm:ss')

    def proc_meter_update(self, msg_obj):
        node_id = msg_obj['HEADER_1'].node_id
        entry_timestamp = int(msg_obj['HEADER_1'].start_timestamp)
        meter_value = int(msg_obj['HEADER_1'].start_meter_value)

        node_uuid = self.get_node_uuid(msg_obj['network_id'], node_id)
        self.ensure_node_exists(node_uuid)

        meter_entries_in = {key: value for key, value in msg_obj.items() if key.startswith(gmsg.A_DETAIL)}
        meter_entries_out = []

        for key, entry in meter_entries_in.items():
            entry_out = entry._asdict()
            entry_timestamp += int(entry.entry_interval_length)
            entry_out['entry_timestamp'] = entry_timestamp
            meter_value += int(entry.entry_value)
            entry_out['meter_value'] = meter_value
            meter_entries_out.append(entry_out)

        last_entry = meter_entries_out[-1]

        self.meters[node_uuid]['last_entry_timestamp'] = last_entry['entry_timestamp']
        self.meters[node_uuid]['last_meter_value'] = last_entry['meter_value']

        self.meter_man.proc_meter_update(node_uuid, meter_entries_out)

        self.logger.info("Got meter update from node " + node_uuid + ".  Last entry was at " +
                         self.uts_to_str(last_entry['entry_timestamp']) + ' value: ' + str(last_entry['meter_value']) + 'Wh')


    def proc_meter_rebase(self, msg_obj):
        node_id = msg_obj['HEADER_1'].node_id
        node_uuid = self.get_node_uuid(msg_obj['network_id'], node_id)
        self.ensure_node_exists(node_uuid)

        self.meters[node_uuid]['last_entry_timestamp'] = msg_obj['DETAIL_2'].entry_timestamp
        self.meters[node_uuid]['last_meter_value'] = msg_obj['DETAIL_2'].meter_value

        self.meter_man.proc_meter_rebase(node_uuid, msg_obj['DETAIL_2'].entry_timestamp, msg_obj['DETAIL_2'].meter_value)
        self.logger.info("Got meter rebase from node " + node_uuid + ".  Last entry was at " +
                         self.uts_to_str(msg_obj['DETAIL_2'].entry_timestamp) + ' value: ' + msg_obj['DETAIL_2'].meter_value + 'Wh')


    def proc_gateway_snapshot(self, msg_obj):
        # gateway object self-updates
        gateway_uuid = self.get_node_uuid(msg_obj['network_id'], msg_obj['gateway_id'])
        rec = msg_obj['HEADER_1']
        self.meter_man.proc_gateway_snapshot(gateway_uuid, msg_obj['when_received'], msg_obj['network_id'], msg_obj['gateway_id'], rec.when_booted,
                                             rec.free_ram, rec.time, rec.log_level,
                                             rec.encrypt_key, rec.tx_power, rec.meter_unit)
        self.logger.info("Got gateway snapshot from gateway: " + gateway_uuid)


    def proc_node_snapshot(self, msg_obj):
        node_snapshots = {key: value for key, value in msg_obj.items() if key.startswith(gmsg.A_DETAIL)}
        for key, ns in node_snapshots.items():
            node_uuid = self.get_node_uuid(msg_obj['network_id'], ns.node_id)
            self.ensure_node_exists(node_uuid)
            self.meters[node_uuid] = {'network_id': msg_obj['network_id'], 'node_id': ns.node_id, 'batt_voltage': ns.batt_voltage,
                                      'up_time': ns.up_time, 'sleep_time': ns.sleep_time,
                                      'free_ram': ns.free_ram, 'last_seen': ns.last_seen,
                                      'last_clock_drift': ns.last_clock_drift, 'meter_interval': ns.meter_interval,
                                      'last_meter_read': ns.last_meter_read, 'last_meter_value': ns.last_meter_value,
                                      'puck_led_rate': ns.puck_led_rate,
                                      'puck_led_time': ns.puck_led_time, 'last_rssi': ns.last_rssi_at_gateway}

            self.meter_man.proc_node_snapshot(node_uuid, msg_obj['when_received'], msg_obj['network_id'], ns.node_id, msg_obj['gateway_id'], ns.batt_voltage,
                                                ns.up_time, ns.sleep_time, ns.free_ram, ns.last_seen, ns.last_clock_drift,
                                                ns.meter_interval, ns.last_meter_read, ns.last_meter_value,
                                                ns.puck_led_rate, ns.puck_led_time, ns.last_rssi_at_gateway)
            self.logger.info("Got node snapshot from node: " + node_uuid)


    def proc_node_dark(self, msg_obj):
        rec = msg_obj['HEADER_1']
        node_uuid = self.get_node_uuid(msg_obj['network_id'], rec.node_id)
        self.ensure_node_exists(node_uuid)
        self.meter_man.proc_node_dark(node_uuid, rec.last_seen)
        self.logger.info("Got node dark from node: " + node_uuid + ".  Last seen at: " + self.uts_to_str(rec.last_seen))


    def proc_gp_msg(self, msg_obj):
        rec = msg_obj['HEADER_1']
        node_uuid = self.get_node_uuid(msg_obj['network_id'], rec.node_id)
        self.ensure_node_exists(node_uuid)
        self.meter_man.proc_gp_msg(node_uuid, msg_obj['when_received'], rec.message)
        self.logger.info("Got general-purpose message from node: " + node_uuid + " - " + rec.message)


    def proc_device_messages(self):
        # processing per gateway/network
        for key, gateway in self.gateways.items():
            # queued messages received from gateway
            new_msgs = {key: value for key, value in gateway['gw_obj'].serial_rx_msg_objects.items() if key > gateway['last_rx_msg_obj']}
            for key, new_msg in new_msgs.items():
                if new_msg['message_type'] == gmsg.SMSG_MTRUPDATE_DEFN['smsg_type']:
                    self.proc_meter_update(new_msg)
                elif new_msg['message_type'] == gmsg.SMSG_MTRREBASE_DEFN['smsg_type']:
                    self.proc_meter_rebase(new_msg)
                elif new_msg['message_type'] == gmsg.SMSG_GWSNAP_DEFN['smsg_type']:
                    self.proc_gateway_snapshot(new_msg)
                elif new_msg['message_type'] == gmsg.SMSG_NODESNAP_DEFN['smsg_type']:
                    self.proc_node_snapshot(new_msg)
                elif new_msg['message_type'] == gmsg.SMSG_NODEDARK_DEFN['smsg_type']:
                    self.proc_node_dark(new_msg)
                elif new_msg['message_type'] == gmsg.SMSG_GPMSG_DEFN['smsg_type']:
                    self.proc_gp_msg(new_msg)
                else:
                    self.logger.warn("Got unknown message object: " + print(new_msg))

                gateway['last_rx_msg_obj'] = key

            # updates from gateway/nodes
            if gateway['last_snap_time'] < arrow.utcnow().shift(seconds=-NODE_UPDATE_INTERVAL_SECS).timestamp:
                gateway['gw_obj'].get_gateway_snapshot()
                gateway['gw_obj'].get_node_snapshot()
                gateway['last_snap_time'] = arrow.utcnow().timestamp


