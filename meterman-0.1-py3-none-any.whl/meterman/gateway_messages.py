'''

================================================================================================================================================================
gateway_messages.py
=====================

Static class for generating gateway messages from transfer objects, and vice-versa.  Separated from gateway implementation
to better support simulation and testing.


================================================================================================================================================================

'''

# ==============================================================================================================================================================
#  IMPORTS
# ==============================================================================================================================================================

import arrow
from enum import Enum
from collections import namedtuple
from random import randint

# ==============================================================================================================================================================
#  CONSTANTS
# ==============================================================================================================================================================
# Serial message and gateway attribute consts
SMSG_RX_PREFIX = "G>S:"
SMSG_TX_PREFIX = "S>G:"
SMSG_FS = ','
SMSG_RS = ';'
A_HEADER = 'HEADER'
A_DETAIL = 'DETAIL'
A_HEADER_SKIP = 'HEADER_SKIP'
A_DETAIL_SKIP = 'DETAIL_SKIP'
A_UNKNOWN = 'UNKNOWN'

# Message Directions
class MessageDirection(Enum):
    GW_TO_SVR = 0
    SVR_TO_GW = 1

# --------------------------------------------------------------------------------------------------------------------------------------------------------------
# Message Definitions:
# Attribute names are unique across header and detail.  Only one detail record type.
# --------------------------------------------------------------------------------------------------------------------------------------------------------------

message_definitions = {}

SMSG_GETTIME_DEFN = {
    #       format:     GETTIME
    #       e.g.:       GETTIME
    'smsg_type': 'GETTIME',
    'smsg_direction': MessageDirection.GW_TO_SVR,
    'smsg_attrib_layout': ['smsg_type'],
    'smsg_attrib_type': [A_HEADER],
}

SMSG_SETTIME_DEFN = {
    # Sends request to gateway to set time to server's local time as Unix UTC Epoch.
    #       format:     SETTIME;<new_epoch_time_utc>
    #       e.g.:       SETTIME;1502795790
    'smsg_type': 'SETTIME',
    'smsg_direction': MessageDirection.SVR_TO_GW,
    'smsg_attrib_layout': ['smsg_type', 'new_epoch_time_utc'],
    'smsg_attrib_type': [A_HEADER_SKIP, A_HEADER]
}

SMSG_SETTIME_ACK_DEFN = {
    #       format:     SETTIME_ACK
    #       e.g.:       SETTIME_ACK
    'smsg_type': 'SETTIME_ACK',
    'smsg_direction': MessageDirection.GW_TO_SVR,
    'smsg_attrib_layout': ['smsg_type'],
    'smsg_attrib_type': [A_HEADER_SKIP]
}

SMSG_SETTIME_NACK_DEFN = {
    #       format:     SETTIME_NACK
    #       e.g.:       SETTIME_NACK
    'smsg_type': 'SETTIME_NACK',
    'smsg_direction': MessageDirection.GW_TO_SVR,
    'smsg_attrib_layout': ['smsg_type'],
    'smsg_attrib_type': [A_HEADER_SKIP]
}

SMSG_GETGWSNAP_DEFN = {
    #  Requests a dump of the gateway's state.
    #       format:     GETGWSNAP
    #       e.g.:       GETGWSNAP
    'smsg_type': 'GETGWSNAP',
    'smsg_direction': MessageDirection.SVR_TO_GW,
    'smsg_attrib_layout': ['smsg_type'],
    'smsg_attrib_type': [A_HEADER_SKIP]
}

SMSG_GWSNAP_DEFN = {
    #       format:     GWSNAP;<gateway_id>,<when_booted>,<free_ram>,<time>,<log_level>,<encrypt_key>,<network_id>,<tx_power>,<meter_unit>
    #       e.g.:       GWSNAP;1,1496842913428,577,1496842913428,DEBUG,PLEASE_CHANGE_ME,1,13,Wh
    'smsg_type': 'GWSNAP',
    'smsg_direction': MessageDirection.GW_TO_SVR,
    'smsg_attrib_layout': ['smsg_type', 'gateway_id', 'when_booted', 'free_ram', 'time', 'log_level', 'encrypt_key', 'network_id',
                            'tx_power', 'meter_unit'],
    'smsg_attrib_type': [A_HEADER_SKIP, A_HEADER, A_HEADER, A_HEADER, A_HEADER, A_HEADER, A_HEADER, A_HEADER, A_HEADER, A_HEADER]
}

SMSG_GETNODESNAP_DEFN = {
    #  Requests a dump of a node's state from the Gateway.
    #       format:     GETNODESNAP;<node_id>       # if no node or node=254 will return all
    #       e.g.:       GETNODESNAP;2
    'smsg_type': 'GETNODESNAP',
    'smsg_direction': MessageDirection.SVR_TO_GW,
    'smsg_attrib_layout': ['smsg_type', 'node_id'],
    'smsg_attrib_type': [A_HEADER_SKIP, A_HEADER]
}

SMSG_NODESNAP_DEFN = {
    #       format:     NODESNAP;[1..n of [<node_id>,<batt_voltage>,<up_time>,<sleep_time>,<free_ram>,<last_seen>,<last_clock_drift>,
    #                       <meter_interval>,<last_meter_read>,<last_meter_value>,<puck_led_rate>,<puck_led_time>,<last_rssi_at_gateway>]]
    #       e.g.:       NODESNAP;2,4500,15000,20000,600,1496842913428,500,5,1496842913428,3050,1,100,-70
    'smsg_type': 'NODESNAP',
    'smsg_direction': MessageDirection.GW_TO_SVR,
    'smsg_attrib_layout': ['smsg_type', 'node_id', 'batt_voltage', 'up_time','sleep_time', 'free_ram','last_seen', 'last_clock_drift',
                           'meter_interval', 'last_meter_read','last_meter_value', 'puck_led_rate', 'puck_led_time','last_rssi_at_gateway'],
    'smsg_attrib_type': [A_HEADER_SKIP, A_DETAIL, A_DETAIL, A_DETAIL, A_DETAIL, A_DETAIL, A_DETAIL, A_DETAIL, A_DETAIL, A_DETAIL, A_DETAIL, A_DETAIL,
                            A_DETAIL, A_DETAIL]
}

SMSG_GETNODESNAP_NACK_DEFN = {
    #       format:     GETNODESNAP_NACK;<node_id>
    #       e.g.:       GETNODESNAP_NACK;2
    'smsg_type': 'GETNODESNAP_NACK',
    'smsg_direction': MessageDirection.GW_TO_SVR,
    'smsg_attrib_layout': ['smsg_type', 'node_id'],
    'smsg_attrib_type': [A_HEADER_SKIP, A_HEADER]
}

SMSG_MTRUPDATE_DEFN = {
    #       format:     MTRUPDATE;<node_id>,MUP,;1..n of [<entry_interval_length>, <entry_value>]
    #       e.g.:       MTRUPDATE;2,MUP,1496842913428,18829393;15,4;15,3;15,2
    'smsg_type': 'MTRUPDATE',
    'rmsg_type': 'MUP',
    'smsg_direction': MessageDirection.GW_TO_SVR,
    'smsg_attrib_layout': ['smsg_type', 'node_id', 'rmsg_type', 'start_timestamp', 'start_meter_value', 'entry_interval_length', 'entry_value'],
    'smsg_attrib_type': [A_HEADER_SKIP, A_HEADER, A_HEADER_SKIP, A_HEADER, A_HEADER, A_DETAIL, A_DETAIL]
}

SMSG_MTRREBASE_DEFN = {
    #       format:     MTRREBASE;<node_id>,MBASE,<entry_timestamp>,<meter_value>
    #       e.g.:       MTRREBASE;2,MBASE,1496842913428,18829393
    'smsg_type': 'MTRREBASE',
    'rmsg_type': 'MBASE',
    'smsg_direction': MessageDirection.GW_TO_SVR,
    'smsg_attrib_layout': ['smsg_type', 'node_id', 'rmsg_type', 'entry_timestamp', 'meter_value'],
    'smsg_attrib_type': [A_HEADER_SKIP, A_HEADER, A_HEADER_SKIP, A_DETAIL, A_DETAIL]
}

SMSG_SETMTRVAL_DEFN = {
    #  Requests a reset of a node's meter value to the value specified.
    #       format:     SETMTRVAL;<node_id>,<new_meter_value>
    #       e.g.:       SETMTRVAL;2,10
    'smsg_type': 'SETMTRVAL',
    'smsg_direction': MessageDirection.SVR_TO_GW,
    'smsg_attrib_layout': ['smsg_type', 'node_id', 'new_meter_value'],
    'smsg_attrib_type': [A_HEADER_SKIP, A_HEADER, A_HEADER]
}

SMSG_SETMTRVAL_ACK_DEFN = {
    #       format:     SETMTRVAL_ACK;<node_id>
    #       e.g.:       SETMTRVAL_ACK;2
    'smsg_type': 'SETMTRVAL_ACK',
    'smsg_direction': MessageDirection.GW_TO_SVR,
    'smsg_attrib_layout': ['smsg_type', 'node_id'],
    'smsg_attrib_type': [A_HEADER_SKIP, A_HEADER]
}

SMSG_SETMTRVAL_NACK_DEFN = {
    #       format:     SETMTRVAL_NACK;<node_id>
    #       e.g.:       SETMTRVAL_NACK;2
    'smsg_type': 'SETMTRVAL_NACK',
    'smsg_direction': MessageDirection.GW_TO_SVR,
    'smsg_attrib_layout': ['smsg_type', 'node_id'],
    'smsg_attrib_type': [A_HEADER_SKIP, A_HEADER]
}

SMSG_SETMTRINT_DEFN = {
    #  Requests a change of a node's metering interval to the value specified.  The interval is the period in seconds at which read entries are created
    #  i.e. (resolution).
    #       format:     SETMTRINT;<node_id>,<new_meter_interval>
    #       e.g.:       SETMTRINT;2,10
    'smsg_type': 'SETMTRINT',
    'smsg_direction': MessageDirection.SVR_TO_GW,
    'smsg_attrib_layout': ['smsg_type', 'node_id', 'new_meter_interval'],
    'smsg_attrib_type': [A_HEADER_SKIP, A_HEADER, A_HEADER]
}

SMSG_SETMTRINT_ACK_DEFN = {
    #       format:     SETMTRINT_ACK;<node_id>
    #       e.g.:       SETMTRINT_ACK;2
    'smsg_type': 'SETMTRINT_ACK',
    'smsg_direction': MessageDirection.GW_TO_SVR,
    'smsg_attrib_layout': ['smsg_type', 'node_id'],
    'smsg_attrib_type': [A_HEADER_SKIP, A_HEADER]
}

SMSG_SETMTRINT_NACK_DEFN = {
    #       format:     SETMTRINT_NACK;<node_id>
    #       e.g.:       SETMTRINT_NACK;2
    'smsg_type': 'SETMTRINT_NACK',
    'smsg_direction': MessageDirection.GW_TO_SVR,
    'smsg_attrib_layout': ['smsg_type', 'node_id'],
    'smsg_attrib_type': [A_HEADER_SKIP, A_HEADER]
}

SMSG_SETPLED_DEFN = {
    #  Requests a change of a node's puck LED rate and time.
    #       format:     SETPLED;<node_id>,<new_puck_led_rate>,<new_puck_led_time>
    #       e.g.:       SETPLED;2,1,100
    'smsg_type': 'SETPLED',
    'smsg_direction': MessageDirection.SVR_TO_GW,
    'smsg_attrib_layout': ['smsg_type', 'node_id', 'new_puck_led_rate', 'new_puck_led_time'],
    'smsg_attrib_type': [A_HEADER_SKIP, A_HEADER, A_HEADER, A_HEADER]
}

SMSG_SETPLED_ACK_DEFN = {
    #       format:     SETPLED_ACK;<node_id>
    #       e.g.:       SETPLED_ACK;2
    'smsg_type': 'GETTIME',
    'smsg_direction': MessageDirection.GW_TO_SVR,
    'smsg_attrib_layout': ['smsg_type', 'node_id'],
    'smsg_attrib_type': [A_HEADER_SKIP, A_HEADER]
}

SMSG_SETPLED_NACK_DEFN = {
    #       format:     SETPLED_NACK;<node_id>
    #       e.g.:       SETPLED_NACK;2
    'smsg_type': 'SETPLED_NACK',
    'smsg_direction': MessageDirection.GW_TO_SVR,
    'smsg_attrib_layout': ['smsg_type', 'node_id'],
    'smsg_attrib_type': [A_HEADER_SKIP, A_HEADER]
}

SMSG_NODEDARK_DEFN = {
    #       format:     NODEDARK;<node_id>,<last_seen>
    #       e.g.:       NODEDARK;2,1496842913428
    'smsg_type': 'NODEDARK',
    'smsg_direction': MessageDirection.GW_TO_SVR,
    'smsg_attrib_layout': ['smsg_type', 'node_id', 'last_seen'],
    'smsg_attrib_type': [A_HEADER_SKIP, A_HEADER, A_HEADER]
}

SMSG_GPMSG_DEFN = {
    #       format:     GPMSG;<node_id>,GPMSG,<message>
    #       e.g.:       GPMSG;2,GPMSG,message
    'smsg_type': 'GPMSG',
    'rmsg_type': 'GPMSG',
    'smsg_direction': MessageDirection.GW_TO_SVR,
    'smsg_attrib_layout': ['smsg_type', 'node_id', 'rmsg_type', 'message'],
    'smsg_attrib_type': [A_HEADER_SKIP, A_HEADER, A_HEADER_SKIP, A_HEADER]
}

# ==============================================================================================================================================================
#  IMPLEMENTATION
# ==============================================================================================================================================================

# ----------------------------------------------------------------------------------------------------------------------------------------------------------
#  Get messages in serial format
# ----------------------------------------------------------------------------------------------------------------------------------------------------------

def get_server_time_msg():
    return get_message_str(SMSG_GETTIME_DEFN)


def set_gateway_time_msg(new_epoch_time_utc):
    return get_message_str(SMSG_SETTIME_DEFN, header={'new_epoch_time_utc': new_epoch_time_utc})


def set_gateway_time_ack_msg():
    return get_message_str(SMSG_SETTIME_ACK_DEFN)


def set_gateway_time_nack_msg():
    return get_message_str(SMSG_SETTIME_NACK_DEFN)


def get_gateway_snapshot_msg():
    return get_message_str(SMSG_GETGWSNAP_DEFN)


def gateway_snapshot_msg(gateway_id, when_booted, free_ram, time, log_level, encrypt_key, network_id, tx_power, meter_unit):
    return get_message_str(SMSG_GWSNAP_DEFN, header={'gateway_id': gateway_id, 'when_booted': when_booted, 'free_ram': free_ram, 'time': time,
                'log_level': log_level, 'encrypt_key': encrypt_key, 'network_id': network_id, 'tx_power': tx_power, 'meter_unit': meter_unit})


def get_node_snapshot_msg(node_id):
    return get_message_str(SMSG_GETNODESNAP_DEFN, header={'node_id':node_id})


def node_snapshot_msg(node_id, batt_voltage, up_time,sleep_time, free_ram, last_seen, last_clock_drift, meter_interval, last_meter_read,
                      last_meter_value, puck_led_rate, puck_led_time,last_rssi_at_gateway):
    return get_message_str(SMSG_NODESNAP_DEFN, detail_recs=[{'node_id': node_id, 'batt_voltage': batt_voltage, 'up_time': up_time, 'sleep_time': sleep_time,
                             'free_ram': free_ram, 'last_seen': last_seen, 'last_clock_drift': last_clock_drift, 'meter_interval': meter_interval,
                             'last_meter_read': last_meter_read, 'last_meter_value': last_meter_value, 'puck_led_rate': puck_led_rate,
                             'puck_led_time': puck_led_time, 'last_rssi_at_gateway': last_rssi_at_gateway}])


def get_node_snapshot_nack_msg():
    return get_message_str(SMSG_GETNODESNAP_NACK_DEFN)


def meter_update_msg(node_id, start_timestamp, start_meter_value, meter_entries):
    # meter entries is list of detail record tuples
    entry_list = []

    for entry in meter_entries:
            entry_list.append({'entry_interval_len': entry.entry_interval_len, 'entry_value': entry.entry_value})

    return get_message_str(SMSG_MTRUPDATE_DEFN, header={'node_id': node_id, 'start_timestamp': start_timestamp, 'start_meter_value': start_meter_value}, detail_recs=entry_list)


def meter_rebase_msg(node_id, entry_timestamp, meter_value):
    return get_message_str(SMSG_MTRREBASE_DEFN, header={'node_id': node_id}, detail_recs=[{'entry_timestamp': entry_timestamp, 'meter_value': meter_value}])


def set_node_meter_value_msg(node_id, new_meter_value):
    return get_message_str(SMSG_SETMTRVAL_DEFN, header={'node_id': node_id, 'new_meter_value': new_meter_value})


def set_node_meter_value_ack_msg():
    return get_message_str(SMSG_SETMTRVAL_ACK_DEFN)


def set_node_meter_value_nack_msg():
    return get_message_str(SMSG_SETMTRVAL_NACK_DEFN)


def set_node_meter_interval_msg(node_id, new_meter_interval):
    return get_message_str(SMSG_SETMTRINT_DEFN, header={'node_id': node_id, 'new_meter_interval': new_meter_interval})


def set_node_meter_interval_ack_msg():
    return get_message_str(SMSG_SETMTRINT_ACK_DEFN)


def set_node_meter_interval_nack_msg():
    return get_message_str(SMSG_SETMTRINT_NACK_DEFN)


def set_node_puck_led_msg(node_id, new_puck_led_rate, new_puck_led_time):
    return get_message_str(SMSG_SETPLED_DEFN, header={'node_id': node_id, 'new_puck_led_rate': new_puck_led_rate, 'new_puck_led_time': new_puck_led_time})


def set_node_puck_led_ack_msg():
    return get_message_str(SMSG_SETPLED_ACK_DEFN)


def set_node_puck_led_nack_msg():
    return get_message_str(SMSG_SETPLED_NACK_DEFN)


def meter_node_dark_msg(node_id, last_seen):
    return get_message_str(SMSG_NODEDARK_DEFN, header={'node_id': node_id, 'last_seen': last_seen})


def general_purpose_msg(node_id, message):
    return get_message_str(SMSG_GPMSG_DEFN, header={'node_id': node_id, 'message': message})


def get_random_meter_update_msg(node_id, start_time=None, start_value=0, interval=15, entry_min=1, entry_max=10):

    if start_time is None:
        start_time = arrow.utcnow().shift(seconds=(-7 * interval)).timestamp

    if randint(0, 30) == 15:
        return meter_rebase_msg(node_id, start_time, start_value)
    else:
        meter_entries = []
        num_elements = randint(1, 7)
        for i in range (1, num_elements):
            entry_value = randint(entry_min, entry_max)
            meter_entries.append({'entry_interval_len': interval, 'entry_value': entry_value})
        return meter_update_msg(node_id, start_time, start_value, meter_entries)


def get_random_gateway_event_msg(node_id):

    msg_selection = randint(0, 4)

    if msg_selection == 0:
        return get_server_time_msg()
    if msg_selection == 1:
        return gateway_snapshot_msg(1, arrow.utcnow().shift(hours=-1).timestamp, 500, arrow.utcnow().timestamp, 'DEBUG', 'CHANGE_ME_PLEASE', '0.0.1.1', -10, 'Wh')
    if msg_selection == 2:
        return node_snapshot_msg(node_id, 4000, 10000, 9000, 700, arrow.utcnow().shift(minutes=-1).timestamp, 5, 15, arrow.utcnow().shift(minutes=-2).timestamp,
                                 50000, 1, 0, -60)
    if msg_selection == 3:
        return meter_node_dark_msg(node_id, arrow.utcnow().shift(minutes=-5).timestamp)
    if msg_selection == 4:
        return general_purpose_msg(node_id, 'HELLO!!!')

# ----------------------------------------------------------------------------------------------------------------------------------------------------------
#  MESSAGE / MSG. OBJECT FUNCTIONS
# ----------------------------------------------------------------------------------------------------------------------------------------------------------

def register_message_defn(message_defn):
    '''
    Adds message definition to dict of definitions, with namedtuples for object header and detail items.
    '''

    tmp_header_defn = []
    tmp_detail_defn = []

    for i, attrib_type in enumerate(message_defn['smsg_attrib_type']):
        if attrib_type == A_HEADER:
            tmp_header_defn.append(message_defn['smsg_attrib_layout'][i])
        elif attrib_type == A_DETAIL:
            tmp_detail_defn.append(message_defn['smsg_attrib_layout'][i])

    message_defn['obj_header_defn'] = namedtuple('Header', tmp_header_defn)
    message_defn['obj_detail_defn'] = namedtuple('Detail', tmp_detail_defn)

    message_definitions[message_defn['smsg_type']] = message_defn


def get_message_str(message_defn, header=None, detail_recs=None):
    '''
    Returns string representation of message object given dict of header, list of dicts of details.
    '''
    message_str = message_defn['smsg_type']
    if header is not None:
        message_str += SMSG_RS
        for i, attr_name in enumerate(message_defn['smsg_attrib_layout']):
            if message_defn['smsg_attrib_type'][i].startswith(A_HEADER):
                if i > 1:
                    message_str += SMSG_FS
                if attr_name is 'rmsg_type':
                    message_str += message_defn['rmsg_type']
                elif attr_name is not 'smsg_type':
                    message_str += str(header[attr_name])

    if detail_recs is not None:
        for detail_record in detail_recs:
            message_str += SMSG_RS
            first_detail = True
            for i, attr_name in enumerate(message_defn['smsg_attrib_layout']):
                if message_defn['smsg_attrib_type'][i].startswith(A_DETAIL):
                    if not first_detail:
                        message_str += SMSG_FS
                    else:
                        first_detail = False
                    message_str += str(detail_record[attr_name])

    return message_str


def get_attrib_defn_idx(message_type, msg_attrib_pos):
    '''
    takes absolute message attribute position (could be greater than number of attribs in msg layout where
    detail record repeats) and returns corresponding message layout index.
    '''

    message_defn = message_definitions[message_type]

    if msg_attrib_pos < len(message_defn['smsg_attrib_layout']):
        return msg_attrib_pos
    else:
        # Are in repeating detail record.  Find position in layout by getting first
        # detail attrib position, subtracting that from current message position, then doing
        # modulo of detail record length
        detail_start_pos = message_defn['smsg_attrib_type'].index(A_DETAIL)
        detail_len = len(message_defn['smsg_attrib_type']) - detail_start_pos
        attrib_defn_pos = detail_start_pos + ((msg_attrib_pos - detail_start_pos) % detail_len)

        return attrib_defn_pos


def get_message_obj(message_str):
    when_received = arrow.utcnow().timestamp

    # remove message rx/tx prefix
    message_str = message_str.replace(SMSG_RX_PREFIX, '')

    # split into records (will be at least 2)
    msg_in_records = message_str.split(SMSG_RS)

    header_defn = None
    detail_defn = None
    message_defn = None
    transfer_obj = {'header_count': 0, 'detail_count': 0, 'message_type': A_UNKNOWN}  # dict used to pass message to processor
    message_attrib_pos = 0
    message_type = A_UNKNOWN
    current_rec_type = A_UNKNOWN
    header_count = 0
    detail_count = 0
    tmp_attr_accumulator = {}  # used to accumulate meter update time and value across message

    for rec_pos, msg_in_record in enumerate(msg_in_records):
        record_attribs = msg_in_record.split(SMSG_FS)
        tmp_transfer_obj = {}

        # iterate through each attribute, building up an output object to be passed to
        # the appropriate processor
        for record_attrib_pos, record_attrib_val in enumerate(record_attribs):
            # message type is first (only) attribute in first record
            if message_attrib_pos == 0:
                message_type = record_attrib_val
                message_defn = message_definitions[message_type]
                header_defn = message_defn['obj_header_defn']
                detail_defn = message_defn['obj_detail_defn']
                transfer_obj['message_type'] = message_type

            else:
                # get position of attribute in message definition
                attrib_defn_pos = get_attrib_defn_idx(message_type, message_attrib_pos)
                attrib_defn_name = message_defn['smsg_attrib_layout'][attrib_defn_pos]
                attrib_defn_type = message_defn['smsg_attrib_type'][attrib_defn_pos]

                # # If mtrupdate, post-process message object to add cumulative totals
                # if attrib_defn_type is A_HEADER and message_type == SMSG_MTRUPDATE_DEFN['smsg_type']:
                #     if attrib_defn_name == 'start_timestamp':
                #         tmp_attr_accumulator['entry_timestamp'] = int(record_attrib_val)
                #     elif attrib_defn_name == 'start_meter_value':
                #         tmp_attr_accumulator['meter_value'] = int(record_attrib_val)
                #
                # if attrib_defn_type is A_DETAIL and message_type == SMSG_MTRUPDATE_DEFN['smsg_type']:
                #     tmp_transfer_obj[attrib_defn_name] = record_attrib_val
                #     if attrib_defn_name == 'entry_interval_len':
                #         tmp_attr_accumulator['entry_timestamp'] += int(record_attrib_val)
                #         tmp_transfer_obj['entry_timestamp'] = tmp_attr_accumulator['entry_timestamp']
                #     elif attrib_defn_name == 'entry_value':
                #         tmp_attr_accumulator['meter_value'] += int(record_attrib_val)
                #         tmp_transfer_obj['meter_value'] = tmp_attr_accumulator['meter_value']

                if attrib_defn_type not in[A_HEADER_SKIP, A_DETAIL_SKIP]:
                    tmp_transfer_obj[attrib_defn_name] = record_attrib_val

                if attrib_defn_type is not current_rec_type and attrib_defn_type in [A_HEADER, A_HEADER_SKIP]:
                    current_rec_type = A_HEADER
                elif attrib_defn_type is not current_rec_type and attrib_defn_type in [A_DETAIL, A_DETAIL_SKIP]:
                    current_rec_type = A_DETAIL

            message_attrib_pos += 1

        if message_attrib_pos > 1:
            # end of record, add transfer object item (named tuple) to transfer object
            if current_rec_type is A_HEADER:
                header_count += 1
                new_obj_item = header_defn(**tmp_transfer_obj)
            else:
                detail_count += 1
                new_obj_item = detail_defn(**tmp_transfer_obj)

            transfer_obj[current_rec_type + '_' + str(rec_pos)] = new_obj_item

    # make transfer object
    transfer_obj['header_count'] = header_count
    transfer_obj['detail_count'] = detail_count
    transfer_obj['when_received'] = when_received

    return transfer_obj


register_message_defn(SMSG_GETTIME_DEFN)
register_message_defn(SMSG_SETTIME_DEFN)
register_message_defn(SMSG_SETTIME_ACK_DEFN)
register_message_defn(SMSG_SETTIME_NACK_DEFN)
register_message_defn(SMSG_GETGWSNAP_DEFN)
register_message_defn(SMSG_GWSNAP_DEFN)
register_message_defn(SMSG_GETNODESNAP_DEFN)
register_message_defn(SMSG_NODESNAP_DEFN)
register_message_defn(SMSG_GETNODESNAP_NACK_DEFN)
register_message_defn(SMSG_MTRUPDATE_DEFN)
register_message_defn(SMSG_MTRREBASE_DEFN)
register_message_defn(SMSG_SETMTRVAL_DEFN)
register_message_defn(SMSG_SETMTRVAL_ACK_DEFN)
register_message_defn(SMSG_SETMTRVAL_NACK_DEFN)
register_message_defn(SMSG_SETPLED_DEFN)
register_message_defn(SMSG_SETPLED_ACK_DEFN)
register_message_defn(SMSG_SETPLED_NACK_DEFN)
register_message_defn(SMSG_SETMTRINT_DEFN)
register_message_defn(SMSG_SETMTRINT_ACK_DEFN)
register_message_defn(SMSG_SETMTRINT_NACK_DEFN)
register_message_defn(SMSG_NODEDARK_DEFN)
register_message_defn(SMSG_GPMSG_DEFN)
