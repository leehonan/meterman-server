'''

================================================================================================================================================================
meter_data_manager.py
=====================

TODO: rename to reflect broader than meter data

================================================================================================================================================================

'''

from enum import Enum

import app_base as base

from meterman import meter_db as db


# Database Meter Entry Types
class EntryType(Enum):
    METER_UPDATE = 0
    METER_REBASE = 1
    SYNTHETIC = 2

# Database Node Event Types
class NodeEventType(Enum):
    BOOT = 0
    DARK = 1
    LOW_BATT = 2


class MeterDataManager:

    def __init__(self):
        self.logger = base.get_logger('data_mgr')
        self.db_mgr = db.DBManager(base.DB_FILE)

        self.meter_entry_cache = {}

        ev_file_config = base.config['EventFile']
        self.do_ev_file = False
        if ev_file_config is not None:
            self.ev_logger = base.get_logger('ev_logger', base.HOME_PATH + ev_file_config['event_file'], True)
            self.do_ev_file = True
            self.ev_log_meter_only = ev_file_config.getboolean('meter_only')


    def close_db(self):
        self.db_mgr.close()
        self.db_mgr = None

    def dictlist_from_rows(self, rows):
        dictlist = []
        for row in rows:
            dictlist.append(dict(zip(row.keys(), row)))
        return dictlist

    def proc_gateway_snapshot(self, gateway_uuid, when_received, network_id, gateway_id, when_booted, free_ram, gw_time, log_level, tx_power, meter_unit):
        self.db_mgr.write_gateway_snapshot(gateway_uuid, int(when_received), network_id, int(gateway_id), int(when_booted), int(free_ram), int(gw_time), log_level,
                          int(tx_power), meter_unit, db.RecStatus.NORMAL.value)
        if self.do_ev_file and (not self.ev_log_meter_only):
            self.ev_logger.info("{},{},{},{},{},{},{},{},{},{},{}".format(
                                    'GWSNAP', gateway_uuid, when_received, network_id, gateway_id, when_booted, free_ram, gw_time, log_level,
                                    tx_power, meter_unit))


    def proc_node_snapshot(self, node_uuid, when_received, network_id, node_id, gateway_id, batt_voltage_mv, up_time, sleep_time, free_ram, last_seen,
                           last_clock_drift, meter_interval, last_meter_read, last_meter_value, puck_led_rate, puck_led_time,
                           last_rssi_at_gateway):
        self.db_mgr.write_node_snapshot(node_uuid, int(when_received), network_id, int(node_id), int(gateway_id), int(batt_voltage_mv), int(up_time),
                                        int(sleep_time), int(free_ram), int(last_seen), int(last_clock_drift), int(meter_interval), int(last_meter_read),
                                        int(last_meter_value), int(puck_led_rate), int(puck_led_time), int(last_rssi_at_gateway), db.RecStatus.NORMAL.value)
        if self.do_ev_file and (not self.ev_log_meter_only):
            self.ev_logger.info("{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{}".format(
                                    'NODESNAP', node_uuid, when_received, network_id, node_id, gateway_id, batt_voltage_mv, up_time, sleep_time, free_ram, last_seen,
                                    last_clock_drift, meter_interval, last_meter_read, last_meter_value, puck_led_rate, puck_led_time,
                                    last_rssi_at_gateway))


    #TODO: is cache worth it?
    def hydrate_cached_meter_entries(self, node_uuid):
        if node_uuid not in self.meter_entry_cache:
            self.meter_entry_cache[node_uuid] = []
        meter_entries = self.db_mgr.get_node_meter_entries(node_uuid, just_latest=True, limit_count=1000)
        if meter_entries is None:
            return

        for entry in self.dictlist_from_rows(meter_entries):
            self.add_to_meter_entry_cache(node_uuid, entry)


    def add_to_meter_entry_cache(self, node_uuid, entry):
        if node_uuid not in self.meter_entry_cache:
            self.meter_entry_cache[node_uuid] = []

        self.meter_entry_cache[node_uuid].append(entry)

        # truncate cache to 1000 newest entries
        del self.meter_entry_cache[node_uuid][0:len(self.meter_entry_cache[node_uuid])-1001]


    def get_cached_meter_entries(self, node_uuid, limit_count=1000):
        if node_uuid in self.meter_entry_cache:
            return self.meter_entry_cache[node_uuid][-limit_count:]
        else:
            return None


    def get_db_meter_entries(self, node_uuid=None, entry_type=None, rec_status=None, time_from=None, time_to=None, just_latest=None, limit_count=None):
        return self.dictlist_from_rows(self.db_mgr.get_node_meter_entries(node_uuid, entry_type, rec_status, time_from, time_to, just_latest, limit_count))


    def get_latest_meter_entries(self, node_uuid=None, limit_count=1000):
        # assumes cache hydrated, nodes seen
        result = []
        if node_uuid is not None and limit_count <= 1000:
            result = self.get_cached_meter_entries(node_uuid, limit_count)
        elif node_uuid is None and limit_count <= 1000:
            get_per_node = limit_count // len(self.meter_entry_cache)
            for key in self.meter_entry_cache:
                result.extend(self.get_cached_meter_entries(key, get_per_node))
        else:
            result = self.get_db_meter_entries(node_uuid, just_latest=True, limit_count=limit_count)

        return result


    def proc_meter_update(self, node_uuid, meter_entries):
        for entry in meter_entries:
            timestamp_nonce = base.get_nonce()
            cache_dict = {'node_uuid': node_uuid, 'timestamp_raw': int(entry['entry_timestamp']), 'timestamp_raw_nonce': timestamp_nonce,
                          'timestamp': int(entry['entry_timestamp']), 'entry_type': EntryType.METER_UPDATE.value, 'entry_value': int(entry['entry_value']),
                          'entry_interval': int(entry['entry_interval_length']), 'meter_value': int(entry['meter_value']),
                          'rec_status': db.RecStatus.NORMAL.value}

            self.add_to_meter_entry_cache(node_uuid, cache_dict)

            self.db_mgr.write_meter_entry(node_uuid, int(entry['entry_timestamp']), timestamp_nonce, int(entry['entry_timestamp']), EntryType.METER_UPDATE.value,
                                          int(entry['entry_value']), int(entry['entry_interval_length']), int(entry['meter_value']), db.RecStatus.NORMAL.value)
            if self.do_ev_file:
                self.ev_logger.info("{},{},{},{},{},{},{},{},{},{}".format('MTRUPDATE', node_uuid, int(entry['entry_timestamp']), timestamp_nonce, int(entry['entry_timestamp']), EntryType.METER_UPDATE.value,
                                          int(entry['entry_value']), int(entry['entry_interval_length']), int(entry['meter_value']), db.RecStatus.NORMAL.value))


    def proc_meter_rebase(self, node_uuid, entry_timestamp, meter_value):
        timestamp_nonce = base.get_nonce()
        self.add_to_meter_entry_cache(node_uuid, {node_uuid, int(entry_timestamp), timestamp_nonce, int(entry_timestamp), EntryType.METER_UPDATE.value,
                                                  0, 0, int(meter_value), db.RecStatus.NORMAL.value})
        self.db_mgr.write_meter_entry(node_uuid, int(entry_timestamp), timestamp_nonce, int(entry_timestamp), EntryType.METER_REBASE.value, int(meter_value), db.RecStatus.NORMAL.value)
        if self.do_ev_file:
            self.ev_logger.info("{},{},{},{},{},{},{}".format('MTRREBASE', int(entry_timestamp), timestamp_nonce, int(entry_timestamp), EntryType.METER_REBASE.value, int(meter_value), db.RecStatus.NORMAL.value))


    def proc_node_event(self, node_uuid, timestamp, event_type, details=None):
        self.db_mgr.write_node_event(node_uuid, timestamp, event_type, details)
