#!flask/bin/python

import ipaddress
import threading

import arrow
from flask import Flask, make_response, jsonify, request
from flask_httpauth import HTTPBasicAuth
from flask_restful import reqparse, Api, Resource

from meterman import app_base as base

MAX_REQ_ITEMS = 1000
DEF_REQ_ITEMS = 100

app = Flask(__name__)
api = Api(app)
auth = HTTPBasicAuth()
meter_man = None
logger = base.get_logger('api')

@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE')
    return response


@auth.get_password
def get_password(username):
    if username == 'lee':
        return 'whoknows0'
    return None


@auth.error_handler
def unauthorized():
    return make_response(jsonify({'error': 'Unauthorized access'}), 403)


def clientInLAN():
    clientIP = ipaddress.ip_address(request.remote_addr)
    local_ip = base.get_ip_address()
    return clientIP in ipaddress.ip_network('127.0.0.1') or clientIP in ipaddress.ip_network(local_ip + '/24')


def validate_utc_ts(utc_ts):
    try:
        return base.MIN_TIME <= arrow.get(utc_ts).timestamp <= base.MAX_TIME
    except ValueError:
        return False

class MeterEntries(Resource):
    # @auth.login_required
    def get(self, node_uuid):
        parser = reqparse.RequestParser()
        parser.add_argument('time_from', type=int, help='start time as epoch UTC, default is none')
        parser.add_argument('time_to', type=int, help='finish time as epoch UTC, default is none')
        parser.add_argument('item_limit', type=int, help='number of results, max is 1000, default is 100')
        args = parser.parse_args()

        time_from = args['time_from']
        time_to = args['time_to']
        item_limit = args['item_limit'] if args['item_limit'] is not None else DEF_REQ_ITEMS

        request_valid = True
        request_bad_messages = []

        if time_from is not None and validate_utc_ts(time_from) is False:
            request_valid = False
            request_bad_messages.append({'api_error': 'Invalid request', 'message': 'Invalid time_from.  Must be valid UNIX epoch timestamp '
                                        'on or before time_to, and between {0} and {1}.'.format(base.MIN_TIME, base.MAX_TIME)})

        if time_to is not None and (validate_utc_ts(time_to) is False or time_to < time_from):
            request_valid = False
            request_bad_messages.append({'api_error': 'Invalid request', 'message': 'Invalid time_to.  Must be valid UNIX epoch timestamp '
                                        'on or after time_from, and between {0} and {1}.'.format(base.MIN_TIME, base.MAX_TIME)})


        if item_limit is not None and not (0 < item_limit <= MAX_REQ_ITEMS):
            request_valid = False
            request_bad_messages.append({'api_error': 'Invalid request', 'message': 'Invalid item_limit.'})

        if not request_valid:
            return make_response(jsonify({'status': 'Bad Request', 'errors': request_bad_messages}), 400)

        meter_entries = meter_man.data_mgr.get_db_meter_entries(node_uuid, time_from=time_from, time_to=time_to,
                                                                    limit_count=item_limit)

        if meter_entries is None:
            return jsonify({'request': {'node_uuid': node_uuid, 'item_limit': item_limit, 'time_from': time_from, 'time_to': time_to},
                    'result': {'meter_entries': None}})
        else:
            return jsonify({'request': {'node_uuid': node_uuid, 'item_limit': item_limit, 'time_from': time_from, 'time_to': time_to},
                    'result': {'meter_entries': meter_entries}})


api.add_resource(MeterEntries, '/meterentries/<node_uuid>')


class MeterEntriesLatest(Resource):
    # @auth.login_required
    def get(self, node_uuid):
        parser = reqparse.RequestParser()
        parser.add_argument('item_limit', type=int, help='number of results, max is 1000, default is 100')
        args = parser.parse_args()

        item_limit = args['item_limit'] if args['item_limit'] is not None else DEF_REQ_ITEMS

        request_valid = True
        request_bad_messages = []

        if item_limit is not None and not (0 < item_limit <= MAX_REQ_ITEMS):
            request_valid = False
            request_bad_messages.append({'api_error': 'Invalid request', 'message': 'Invalid item_limit.'})

        if not request_valid:
            return make_response(jsonify({'status': 'Bad Request', 'errors': request_bad_messages}), 400)

        # attempts to fetch from cache
        meter_entries = meter_man.data_mgr.get_latest_meter_entries(node_uuid, item_limit)

        if meter_entries is None:
            return jsonify({'request': {'node_uuid': node_uuid, 'item_limit': item_limit},
                    'result': {'meter_entries': None}})
        else:
            return jsonify({'request': {'node_uuid': node_uuid, 'item_limit': item_limit},
                    'result': {'meter_entries': meter_entries}})

api.add_resource(MeterEntriesLatest, '/meterentries/latest/<node_uuid>')


class ApiCtrl:

    def __init__(self, meter_man_obj):
        global meter_man
        meter_man = meter_man_obj
        self.run_thread = None

    def run(self):
        base.logger.info("Starting API implementation server...")
        self.run_thread = threading.Thread(target=app.run, kwargs={'host': '0.0.0.0', 'port': 8000, 'debug': False})
        self.run_thread.daemon = True  # Daemonize thread
        self.run_thread.start()  # Start the execution




